package com.iappsdata.hrms.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iappsdata.hrms.daoImpl.DepartmentsRepo;
import com.iappsdata.hrms.daoImpl.LeaveManagementRepo;
import com.iappsdata.hrms.dto.DepartmentsDto;
import com.iappsdata.hrms.dto.LeaveManagementDto;
import com.iappsdata.hrms.entities.Departments;
import com.iappsdata.hrms.entities.LeaveManagement;

@Service
public class LeaveManagementServiceImple {

	@Autowired
	LeaveManagementRepo leaveManagementRepo;

	public String save(LeaveManagementDto leaveManagementDto) {

		LeaveManagement leaveManagement = new LeaveManagement();
		leaveManagementRepo.save(leaveManagement);
		return "";
	}

}
