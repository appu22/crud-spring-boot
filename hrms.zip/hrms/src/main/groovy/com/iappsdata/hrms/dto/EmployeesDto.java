package com.iappsdata.hrms.dto;

/**
 * Employees entity class
 * 
 * @author Appayya
 */
public class EmployeesDto {

	private String firstName;
	private String lastName;
	private String department;
	private Long phoneNo;

	public EmployeesDto(String firstName, String lastName, String department, Long phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.phoneNo = phoneNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Employees [firstName=" + firstName + ", lastName=" + lastName + ", department=" + department
				+ ", phoneNo=" + phoneNo + "]";
	}

}
