package com.iappsdata.hrms.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iappsdata.hrms.daoImpl.EmployeeRepo;
import com.iappsdata.hrms.dto.EmployeesDto;
import com.iappsdata.hrms.entities.Employees;

@Service
public class EmployeeServiceImpl {

	@Autowired
	EmployeeRepo employeeRepo;

	public String save(EmployeesDto employees) {

		Employees empEnity = new Employees();

		employeeRepo.save(empEnity);
		return "";
	}

}
