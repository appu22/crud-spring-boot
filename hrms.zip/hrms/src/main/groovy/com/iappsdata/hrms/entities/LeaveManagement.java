package com.iappsdata.hrms.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class LeaveManagement {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private Employees employees;
	private String leaveType;
	private String startDate;
	private String endDate;

	public LeaveManagement() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LeaveManagement(Employees employees, String leaveType, String startDate, String endDate) {
		super();
		this.employees = employees;
		this.leaveType = leaveType;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Employees getEmployees() {
		return employees;
	}

	public void setEmployees(Employees employees) {
		this.employees = employees;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "LeaveManagement [id=" + id + ", employees=" + employees + ", leaveType=" + leaveType + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}

}
