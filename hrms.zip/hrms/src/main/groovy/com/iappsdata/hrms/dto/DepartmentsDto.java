package com.iappsdata.hrms.dto;

public class DepartmentsDto {

	private String departmentName;
	private String departmentNo;
	private String location;

	public DepartmentsDto(String departmentName, String departmentNo, String location) {
		super();
		this.departmentName = departmentName;
		this.departmentNo = departmentNo;
		this.location = location;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentNo() {
		return departmentNo;
	}

	public void setDepartmentNo(String departmentNo) {
		this.departmentNo = departmentNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Departments [departmentName=" + departmentName + ", departmentNo=" + departmentNo + ", location="
				+ location + "]";
	}

}
