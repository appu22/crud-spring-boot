package com.iappsdata.hrms.dao;

import org.springframework.stereotype.Component;

import com.iappsdata.hrms.entities.Employees;

@Component
public interface EmployeesDao {

	Employees save(Employees emp);

}
