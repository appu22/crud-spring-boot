package com.iappsdata.hrms.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class LeaveManagementDto {

	private EmployeesDto employees;
	private String leaveType;
	private String startDate;
	private String endDate;

	public LeaveManagementDto(EmployeesDto employees, String leaveType, String startDate, String endDate) {
		super();
		this.employees = employees;
		this.leaveType = leaveType;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public EmployeesDto getEmployees() {
		return employees;
	}

	public void setEmployees(EmployeesDto employees) {
		this.employees = employees;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "LeaveManagement [employees=" + employees + ", leaveType=" + leaveType + ", startDate=" + startDate
				+ ", endDate=" + endDate + "]";
	}

}
