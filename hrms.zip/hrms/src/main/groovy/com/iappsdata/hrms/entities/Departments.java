package com.iappsdata.hrms.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Departments {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private String departmentName;
	private String departmentNo;
	private String location;

	public Departments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Departments(String departmentName, String departmentNo, String location) {
		super();
		this.departmentName = departmentName;
		this.departmentNo = departmentNo;
		this.location = location;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentNo() {
		return departmentNo;
	}

	public void setDepartmentNo(String departmentNo) {
		this.departmentNo = departmentNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Departments [id=" + id + ", departmentName=" + departmentName + ", departmentNo=" + departmentNo
				+ ", location=" + location + "]";
	}

}
