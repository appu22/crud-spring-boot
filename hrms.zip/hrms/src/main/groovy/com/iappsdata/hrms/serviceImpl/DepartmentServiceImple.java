package com.iappsdata.hrms.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iappsdata.hrms.daoImpl.DepartmentsRepo;
import com.iappsdata.hrms.dto.DepartmentsDto;
import com.iappsdata.hrms.entities.Departments;

@Service
public class DepartmentServiceImple {

	@Autowired
	DepartmentsRepo departmentsRepo;

	public String save(DepartmentsDto departmentsDto) {
		Departments departments = new Departments();

		departmentsRepo.save(departments);
		return "";
	}
}
