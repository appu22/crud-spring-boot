package com.iappsdata.hrms.daoImpl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iappsdata.hrms.entities.LeaveManagement;

@Repository
public interface LeaveManagementRepo extends JpaRepository<LeaveManagement, Integer> {

}
